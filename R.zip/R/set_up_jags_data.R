#' Set up the inputs used in the jags model for estimating the proportion of modern contraceptive methods supplied by the public & private Sectors using a Bayesian hierarchical penalized spline model
#' @name set_up_jags_data
#' @param mydata The DHS data SE_source_data_20.RDS from /data folder. Contains data for countries participating in the FP2030 initiative.
#' @param nseg Ghe number of knots to use in the splines. Default is 12.
#' @return returns a list of jags model inputs
#' @export

set_up_jags_data <- function(mydata, nseg=12) {
  FP_source_data_wide <- mydata %>% # Proportion data
    dplyr::ungroup() %>%
    dplyr::select(Country, Region, Method, average_year, sector_category, prop.trans, n) %>%
    dplyr::rename(proportion = prop.trans) %>%
    dplyr::group_by(Country, Region, Method, average_year, sector_category) %>%
    dplyr::distinct() %>%
    tidyr::pivot_wider(names_from = sector_category, values_from = c(proportion,n)) %>%
    dplyr::rename(Commercial_medical = proportion_Commercial_medical ) %>%
    dplyr::rename(Public = proportion_Public ) %>%
    dplyr::rename(Other = proportion_Other) %>%
    dplyr::arrange(Country)

  FP_source_data_wide <- FP_source_data_wide %>%
    dplyr::rowwise() %>%
    dplyr::mutate(check_total = sum(Commercial_medical, Other, Public, na.rm = TRUE))

  # Fill in single missing NA values with 1-sum(others) ----------------------------------------------------
  FP_source_data_wide$count_NA <- rowSums(is.na(FP_source_data_wide[, c("Commercial_medical", "Other","Public")])) # count NAs
  FP_source_data_wide <- FP_source_data_wide %>% dplyr::filter(count_NA <2) # Remove obs with two missing sectors
  FP_source_data_wide$remainder <- 1 - rowSums(FP_source_data_wide[, c("Commercial_medical", "Other","Public")], na.rm = TRUE)

  for(i in 1:nrow(FP_source_data_wide)) {
    if(FP_source_data_wide$count_NA[i]==1) {
      na_col_num <- which(is.na(FP_source_data_wide[i,c("Commercial_medical", "Other","Public")])) # column number of NA
      FP_source_data_wide[i,na_col_num+5] <- FP_source_data_wide[i,"remainder"] # replace with remainder
    } else {
      next
    }
  }

  # Replace any negative numbers with approximately 0
  FP_source_data_wide <- FP_source_data_wide %>%
    dplyr::rowwise() %>%
    dplyr::mutate(Public = ifelse(Public < 0, 0.001, Public)) %>%
    dplyr::mutate(Commercial_medical = ifelse(Commercial_medical < 0, 0.001, Commercial_medical)) %>%
    dplyr::mutate(Other = ifelse(Other < 0, 0.001, Other))

  ## Remove SE missing for two sectors -------------------------------------------------------------------
  SE_source_data_wide <- mydata %>% # SE data
    dplyr::ungroup() %>%
    dplyr::select(Country, Region, Method, average_year, sector_category, SE.proportion) %>%
    tidyr::pivot_wider(names_from = sector_category, values_from = SE.proportion) %>%
    dplyr::arrange(Country) %>%
    dplyr::rename(Public.SE = Public, Commercial_medical.SE = Commercial_medical, Other.SE = Other)

  # Readjust any SE <1% to 1% -------------------------------------------------------------------
  SE_source_data_wide <- SE_source_data_wide %>%
    dplyr::rowwise() %>%
    dplyr::mutate(Public.SE = ifelse(Public.SE < 0.01, 0.01, Public.SE)) %>%
    dplyr::mutate(Commercial_medical.SE = ifelse(Commercial_medical.SE < 0.01, 0.01, Commercial_medical.SE)) %>%
    dplyr::mutate(Other.SE = ifelse(Other.SE < 0.01, 0.01, Other.SE))

  SE_source_data_wide$count_NA <- rowSums(is.na(SE_source_data_wide)) # count NAs
  SE_source_data_wide <- SE_source_data_wide %>% dplyr::filter(count_NA <2) # Remove obs with two missing sectors

  # Max of column SE in country for missing values -----------------------------------------------------
  SE_source_data_wide <- SE_source_data_wide %>%
    dplyr::ungroup() %>%
    dplyr::group_by(Country) %>%
    dplyr::mutate(max.Other.SE = max(Other.SE, na.rm=TRUE)) %>%
    dplyr::mutate(Other.SE = ifelse(is.na(Other.SE)==TRUE, max.Other.SE, Other.SE)) %>%
    dplyr::mutate(max.Public.SE = max(Public.SE, na.rm=TRUE)) %>%
    dplyr::mutate(Public.SE = ifelse(is.na(Public.SE)==TRUE, max.Public.SE, Public.SE)) %>%
    dplyr::mutate(max.Commercial_medical.SE = max(Commercial_medical.SE, na.rm=TRUE)) %>%
    dplyr::mutate(Commercial_medical.SE = ifelse(is.na(Commercial_medical.SE)==TRUE, max.Commercial_medical.SE, Commercial_medical.SE)) %>%
    dplyr::select(Country, Region, Method, average_year, Commercial_medical.SE, Public.SE, Other.SE, count_NA)

  # Merge SE and proportion data together -----------------------------------------------------
  FP_source_data_wide <- dplyr::left_join(FP_source_data_wide, SE_source_data_wide)

  # Adding indexes to proportion -----------------------------------------------------
  FP_source_data_wide <- country_index_fun(FP_source_data_wide, unique(FP_source_data_wide$Country))
  FP_source_data_wide <- region_index_fun(FP_source_data_wide, unique(FP_source_data_wide$Region))
  n_method <- c("Female Sterilization","Implants", "Injectables", "IUD","OC Pills")
  FP_source_data_wide <- method_index_fun(FP_source_data_wide, n_method)

  # Time indexing - important for splines -----------------------------------
  all_years <- seq(from = 1990, to = 2025.5, by=0.5)
  n_all_years <- length(all_years)

  time_index_table <- tibble::tibble(average_year = all_years, index_year = 1:length(all_years))

  FP_source_data_wide <- FP_source_data_wide %>%
    dplyr::mutate(index_year = match(average_year,all_years))

  # Get T_star and match_Tstar-----------------------------------------------
  T_star <- FP_source_data_wide %>%
    dplyr::group_by(Country) %>%
    dplyr::filter(index_year==max(index_year)) %>%
    dplyr::select(Country, index_country, average_year, index_year) %>%
    dplyr::arrange(index_country) %>%
    dplyr::ungroup() %>%
    dplyr::select(index_country, index_year, average_year) %>%
    dplyr::distinct()

  # setup for JAGS data -----------------------------------------------------
  t_seq_2 <- floor(FP_source_data_wide$index_year) # Time sequence for countries
  country_seq <- FP_source_data_wide$Country
  n_country <- as.character(unique(country_seq))
  n_region <- unique(FP_source_data_wide$Region)
  n_sector <- c("Public", "Commercial_medical", "Other") # Names of categories
  n_obs <- nrow(FP_source_data_wide) # Total number of observations
  year_seq <- seq(min(t_seq_2),max(t_seq_2), by=1)
  n_years <- length(year_seq)

  # Find the observation year indexes in the prediction years
  match_country <- FP_source_data_wide$index_country
  match_years <- FP_source_data_wide$index_year
  match_method <- FP_source_data_wide$index_method
  region_country <- FP_source_data_wide %>%
    dplyr::select(Country, Region, index_country, index_region) %>%
    dplyr::distinct()
  match_region <- region_country$index_region

  # splines -----------------------------------------------------------------
  nseg=12
  Kstar <- vector()
  B.ik <- array(dim = c(length(n_country), length(all_years),nseg+3))
  knots.all <- matrix(nrow = length(n_country), ncol=nseg+3)

  for(i in 1:nrow(T_star)) {
    index_mc <- T_star$average_year[i]
    res <- bs_bbase_precise(all_years, lastobs=index_mc, nseg = nseg) # number of splines based on segments, here choosing 10
    B.ik[i,,] <- res$B.ik
    Kstar[i] <- res$Kstar
    knots.all[i,] <- res$knots.k
  }

  K <- dim(res$B.ik)[2]
  H <- K-1

  load("data/estimated_rho_matrix.rda")

  estimated_rho_matrix <- estimated_rho_matrix %>%
    dplyr::select(row, column, public_cor, private_cor)

  my_SE_rho_matrix <- estimated_rho_matrix %>%
    dplyr::select(public_cor, private_cor)


  return(list(y = FP_source_data_wide[,c("Public", "Commercial_medical")],
              se_prop = FP_source_data_wide[,c("Public.SE", "Commercial_medical.SE")],
              rho = my_SE_rho_matrix,
              tstar = T_star$index_year,
              kstar = Kstar,
              B.ik = B.ik,
              all_years = all_years,
              n_years = n_all_years,
              n_obs = n_obs,
              K = K,
              H = H,
              n_country = n_country,
              n_region = n_region,
              n_method = n_method,
              R_count = length(n_region),
              C_count = length(n_country),
              M_count = length(n_method),
              matchregion = match_region,
              matchcountry = match_country,
              matchmethod = match_method,
              matchyears = match_years
  ))
}
